module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['res.cloudinary.com', 'localhost', 'portfolio.haruthya.my.id'],
  },
}
