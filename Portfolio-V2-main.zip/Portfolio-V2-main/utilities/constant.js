const constant = {
    baseUrl: "https://portfolio.haruthya.my.id/api/content",
    path: "https://blooming-taiga-09629.herokuapp.com",
    storage: "https://portfolio.haruthya.my.id/storage/uploads/",
    url: "https://harithya.vercel.app/",
    keyword: 'Harithya Wisesa,Programmer Tasik, Haritya, Haritia, Frontend Developer, Developer, Programmer, Tasikmalaya',
    key: "API-6a9fcbb10229b34e167354e6dd1a698dbafc04ee"
}

export default constant
