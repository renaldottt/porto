import constant from "./constant"

const common = {
    image: (val) => val

}

export default common